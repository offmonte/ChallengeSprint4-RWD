// pages/addBike.js
import React from 'react';
import './addBike.css';

function AddBike() {
  return (
    <container className="telaAdicionarSeguro">
      <h1>Adicionando seguro</h1>
      <div className="adicionarSeguro">
        <h2>Precisamos de algumas informações da sua bike</h2>
        <div className="gridding">
          <div className="part1">
            <input type="text" id="modelo" name="modelo" placeholder="Modelo" required={true}/>
            <input type="text" id="serie" name="serie" placeholder="Número de série" required={true}/>
            <input type="text" id="ano" name="ano" placeholder="Ano da bike" required={true}/>
          </div>
          <div className="part2">
            <input type="text" id="acessorio" name="acessorio" placeholder="Acessórios (se possuir)" />
            <input type="text" id="valor" name="valor" placeholder="Valor em reais (R$)" required={true}/>
            <button type="submit">Contratar seguro</button>
          </div>
        </div>
      </div>
    </container>
  );
}

export default AddBike;
