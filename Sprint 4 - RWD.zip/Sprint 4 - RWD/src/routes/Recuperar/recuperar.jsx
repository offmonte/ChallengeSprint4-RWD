import React from 'react';
import './recuperar.css';
import { Link } from "react-router-dom"

function Recuperar() {
  return (
    <div className="telaRecuperar">
      <h1>Recuperação de conta</h1>
      <div className="recuperarConta">

        <p>Digite o número de celular cadastrado à conta para que possamos entrar em contato com um link para recuperação de conta</p>
        <input type="text" id="celular" name="celular" placeholder="Número de celular" required={true} />
        <button type="submit">Solicitar recuperação de conta</button>
      </div>
    </div>
  );
}

export default Recuperar;
