import React from 'react';
import './login';
import { Link } from "react-router-dom"

function Login() {
  return (
    <div className="telaLogin">
      <h1>Acesse sua conta</h1>
      <div className="efetuarLogin">

        <input type="email" id="email" name="email" placeholder="Endereço de email" required />
        <Link to='/recuperar'>Esqueci meu email</Link>

        <input type="password" id="CPF" name="CPF" placeholder="CPF" required />
        <Link to='/recuperar'>Não consigo entrar com meu CPF</Link>

        <button type="submit">Entrar</button>

        <Link to='/cadastrar'>Ainda não possui conta? Clique aqui!</Link>
      </div>
    </div>
  );
}

export default Login;
