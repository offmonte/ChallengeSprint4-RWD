function validar(){
    
    email = document.getElementById("txtEmail");

    if(email.value == "" || email.value.length < 20){
        alert("Campo email é obrigatório!");
        email.style.backgroundColor = '#ffafaf';
        email.focus();
        return false;
    }
    else{
        email.style.backgroundColor = 'white';
    }


    cpf = document.getElementById("cpf");

    if(cpf.value == "" || cpf.value.length < 11){
        alert("Campo CPF é obrigatório!");
        cpf.style.backgroundColor = '#ffafaf';
        cpf.focus();
        return false;
    }
    else{
        cpf.style.backgroundColor = 'white';
    }

    
}
