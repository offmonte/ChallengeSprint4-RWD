import React from 'react';
import { Link } from 'react-router-dom';
import './index.css';


function Index() {
  return (
    <div>
        <header>
            <nav className="login">
                <ul className="listaHeader">
                    <li className="itemHeader"><Link to="/cadastrar">Cadastrar</Link></li>
                    <li className="itemHeader"><Link to="/login">Fazer login</Link></li>
                </ul>
            </nav>
        </header>
        <div className="corpo">
            <section className="anuncio">
                <div className="sobreSeguro">
                    <h2>SOBRE NOSSO SEGURO:</h2>
                    <div className="espec">
                        <ul className="listaEspec">
                            <li className="itemEspec">✔ Quebra Acidental</li>
                            <li className="itemEspec">✔ Roubo</li>
                            <li className="itemEspec">✔ Furto Qualificado</li>
                        </ul>
                        <ul className="listaEspec">
                            <li className="itemEspec">✔ Sem Carência</li>
                            <li className="itemEspec">✔ 100% Online</li>
                            <li className="itemEspec">✔ Assistência 24h</li>
                        </ul>
                    </div>
                </div>
                <img src="./imagesIndex/Ciclista_Principal.png" alt="Ciclista" className="ciclistaPrincipal"/>
            </section>
            <section className="mostruario">
                <h1> Pedale com Tranquilidade</h1>
                <h3> Conte conosco em todas as situações, sem restrições.</h3>
                <div className="tiposBikes">
                    <div className="Bike">
                        <h4>Moutain Bike</h4>
                        <img src="./imagesIndex/Moutain_Bike.png" alt="Moutain Bike"/>
                    </div>
                    <div className="Bike">
                        <h4>Performance</h4>
                        <img src="./imagesIndex/Performance_Bike.png" alt="Performance Bike"/>
                    </div>
                    <div className="Bike">
                        <h4>Urbano</h4>
                        <img src="./imagesIndex/Urbano_Bike.png" alt="Urbano Bike"/>
                    </div>
                </div>
                <Link to="/login" className="contrate">Contrate nosso seguro!</Link>
            </section>
        </div>
    </div>
  );
}

export default Index;
