import React from 'react';
import './cadastro.css';
import { Link } from "react-router-dom"

function ConcluirCadastro() {
  return (
    <div className="telaCad">
      <img src="./images/Chroma_Logo.png" height="300px" width="300" alt="Chroma Cycle Logo" className="logo" />
      <div className="conluirCad">
        <h1>Quase lá! Falta pouco</h1>

        <div className="part3">
          <div className="gridding">
            <input type="text" id="nascimento" name="nascimento" className="menores" placeholder="Nascimento" required={true} />
            <input type="text" id="CEP" name="CEP" className="menores" placeholder="CEP" required={true} />
          </div>

          <input type="text" id="endereco" name="endereco" className="endereco" placeholder="Endereço" required={true} />
          <div className="gridding">
            <input type="text" id="numero" className="menores" name="numero" placeholder="Número" required={true} />
            <input type="text" id="complemento" className="menores" name="complemento" placeholder="Complemento (se possuir)" />
          </div>
        </div>

        <button type="submit">Concluir cadastro</button>
      </div>
    </div>
  );
}

export default ConcluirCadastro;
