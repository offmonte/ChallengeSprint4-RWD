// pages/usuario.js
import { Link } from "react-router-dom"
import React from 'react';
import './usuario.css';

function Usuario() {
  return (
    <container class="telaUsuario">
        
        <div class="gridding">

            <div class="dadosUsuario">
                <h2>Lucas Monte Verde</h2>
                <h4>ID#12112002</h4>
                <div class="gridMenor">
                    <div class="dados">
                        <h3>lucasmonte@gmail.com</h3>
                        <h3>+55 (11) 98765-4321</h3>
                        <h3>*** . *** . *** - **</h3>
                    </div>
                    
                    <div class="dados">
                        <h3>12/11/2002</h3>
                        <h3>Avenida Paulista, 2024</h3>
                        <h3>São Paulo, SP, Brasil</h3>
                    </div>
                </div>
            </div>
            
            <div class="dadosSeguros">
                <h1>Seguros Ativos</h1>
                <section class="segurosAtivos">
                    <div class="gridding">
                        <div class="part1">
                            <h2>BMX-5051</h2>
                            <h4>ID#1234</h4>
                        </div>
                        <div class="part2">
                            <h3>Valor do seguro:</h3>
                            <h3>R$ 56,29 /mês</h3>
                        </div>
                    </div>
                    <p> Ano da bike: 2022</p>
                    <p> Possui modificações.</p>
                </section>
                <section class="segurosAtivos">
                    <div class="gridding">
                        <div class="part1">
                            <h2>BMX-5051</h2>
                            <h4>ID#1234</h4>
                        </div>
                        <div class="part2">
                            <h3>Valor do seguro:</h3>
                            <h3>R$ 56,29 /mês</h3>
                        </div>
                    </div>
                    <p> Ano da bike: 2022</p>
                    <p> Possui modificações.</p>
                </section>
                <section class="segurosAtivos">
                    <div class="gridding">
                        <div class="part1">
                            <h2>BMX-5051</h2>
                            <h4>ID#1234</h4>
                        </div>
                        <div class="part2">
                            <h3>Valor do seguro:</h3>
                            <h3>R$ 56,29 /mês</h3>
                        </div>
                    </div>
                    <p> Ano da bike: 2022</p>
                    <p> Possui modificações.</p>
                </section>
                <Link to='/addBike' className="botaoAddBike">Adicionar seguro</Link>
            </div>
            
        </div>
    </container>
  );
}

export default Usuario;
