export default function Error() {
    return(
        <>
            <h1>Error 404 - Not found</h1>
       
        </>
    )
}