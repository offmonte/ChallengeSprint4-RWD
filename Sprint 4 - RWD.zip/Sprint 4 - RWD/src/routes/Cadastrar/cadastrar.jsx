import React from 'react';
import './cadastro.css';
import { Link } from "react-router-dom"

function Cadastrar() {
  return (
    <div className="telaCad">
      <div className="efetuarCad">
        <h1>Crie sua conta</h1>
        <div className="gridding">
          <div className="part1">
            <input type="text" id="nome" name="nome" placeholder="Nome" required={true} />
            <input type="email" id="email" name="email" placeholder="Endereço de email" required={true} />
            <input type="text" id="CPF" name="CPF" placeholder="CPF" required={true} />
          </div>

          <div className="part2">
            <input type="text" id="sobrenome" name="sobrenome" placeholder="Sobrenome" required={true} />
            <input type="email" id="confirmarEmail" name="confirmarEmail" placeholder="Confirme o email" required={true} />
            <input type="text" id="celular" name="celular" placeholder="Celular" required={true} />
          </div>
        </div>

        <button type="submit">Começar cadastro</button>
        <Link className='Link' to='/login'>Já possui conta? Clique aqui!</Link>
      </div>

      <img src="./images/Chroma_Logo.png" height="300px" width="300" alt="Chroma Cycle Logo" className="logo" />
    </div>
  );
}

export default Cadastrar;
