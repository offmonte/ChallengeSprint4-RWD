function validar(){
    
    nome = document.getElementById("txtNome");

    if(nome.value == "" || nome.value.length < 8){
        alert("Campo nome é obrigatório!");
        nome.style.backgroundColor = '#ffafaf';
        nome.focus();
        return false;
    }
    else{
        nome.style.backgroundColor = 'white';
    }

    email = document.getElementById("email");

    if(email.value == "" || email.value.length < 10){
        alert("Campo Email é obrigatório!");
        email.style.backgroundColor = '#ffafaf';
        email.focus();
        return false;
    }
    else{
        email.style.backgroundColor = 'white';
    }
    cpf = document.getElementById("cpf");

    if(cpf.value == "" || cpf.value.length < 11){
        alert("Campo CPF é obrigatório!");
        cpf.style.backgroundColor = '#ffafaf';
        cpf.focus();
        return false;
    }
    else{
        cpf.style.backgroundColor = 'white';
    }


    sobrenome = document.getElementById("txtSobrenome");

    if(sobrenome.value == "" || sobrenome.value.length < 10){
        alert("Campo sobrenome é obrigatório!");
        sobrenome.style.backgroundColor = '#ffafaf';
        sobrenome.focus();
        return false;
    }
    else{
        sobrenome.style.backgroundColor = 'white';
    }

    confirmarEmail = document.getElementById("confirmarEmail");

    if(confirmarEmail.value == "" || confirmarEmail.value.length < 10){
        alert("Campo Confirmar Email é obrigatório!");
        confirmarEmail.style.backgroundColor = '#ffafaf';
        confirmarEmail.focus();
        return false;
    }
    else{
        confirmarEmail.style.backgroundColor = 'white';
    }

    celular = document.getElementById("celular");

    if(celular.value == "" || celular.value.length < 10){
        alert("Campo Celular é obrigatório!");
        celular.style.backgroundColor = '#ffafaf';
        celular.focus();
        return false;
    }
    else{
        celular.style.backgroundColor = 'white';
    }
    
}