import React from 'react';
import './quemSomos.css';


function QuemSomos() {
  return (
    <div className="quemSomos">
      <div className="part1">
        <div className="aluno">
          <img src="./imagesIntegrantes/Lucas.png" height="100px" width="100" alt="Aluno" className="Aluno" />
          <h2> Lucas Monte Verde</h2>
          <h3> RM: 551604</h3>
        </div>
        <div className="aluno">
          <img src="./imagesIntegrantes/Mark.jpg" height="100px" width="100" alt="Aluno" className="Aluno" />
          <h2> Marcos Henrique Garrido da Silva</h2>
          <h3> RM: 99578</h3>
        </div>
        <div className="aluno">
          <img src="./imagesIntegrantes/Izabelly.png" height="100px" width="100" alt="Aluno" className="Aluno" />
          <h2> Izabelly de Oliveira Menezes</h2>
          <h3> RM: 551423</h3>
        </div>
      </div>
      <div className="part2">
        <div className="aluno">
          <img src="./imagesIntegrantes/Gustavo.png" height="100px" width="100" alt="Aluno" className="Aluno" />
          <h2> Gustavo Imparto Chaves</h2>
          <h3> RM: 551988</h3>
        </div>
        <div className="aluno">
          <img src="./imagesIntegrantes/JoaoVito.png" height="100px" width="100" alt="Aluno" className="Aluno" />
          <h2> João Vito Santiago da Silva</h2>
          <h3> RM: 86293</h3>
        </div>
      </div>
    </div>
  );
}

export default QuemSomos;
