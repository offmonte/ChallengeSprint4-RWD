import { Link } from "react-router-dom"
import React from 'react';
import './suporte.css';

function Suporte() {
  return (
    <div className="suporte">
      <div className="contato">
        <h2>Mande um email para nós</h2>
        <h3>Mande um email para nosso suporte: <br /> chromacycle@suporte.com</h3>
      </div>
      <div className="contato">
        <h2>Prefere nos ligar?</h2>
        <h3>Ligue para nós no número: <br /> (11) 1234-5678</h3>
      </div>
      <div className="contato">
        <h2>Suporte WhatsApp</h2>
        <h3>Converse conosco pelo WhatsApp: <br /> +55 (11) 98765-4321</h3>
      </div>
    </div>
  );
}

export default Suporte;
