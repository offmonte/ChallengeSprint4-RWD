import React from 'react'
import ReactDOM from 'react-dom'
import  {BrowserRouter, Outlet}  from 'react-router-dom'

import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import App from './App.jsx'
import AddBike from './routes/AddBike/addBike.jsx'
import Cadastrar from './routes/Cadastrar/cadastrar.jsx'
import ConcluirCadastro from './routes/ConcluirCadastro/concluirCadastro.jsx'
import Home from './routes/Home/index.jsx'
import Login from './routes/Login/login.jsx'
import QuemSomos from './routes/QuemSomos/quemSomos.jsx'
import Recuperar from './routes/Recuperar/recuperar.jsx'
import Suporte from './routes/Suporte/suporte.jsx'
import Usuario from './routes/Usuario/usuario.jsx'
import Error from './routes/Error/error.jsx'


const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    errorElement: <Error />,
    children: [
      {
        path: '/addBike',
        element: <AddBike />
      },

      {
        path: '/cadastrar',
        element: <Cadastrar />
      },

      {
        path: '/concluirCadastro',
        element: <ConcluirCadastro/>
      },

      {
        path: '/home',
        element: <Home />
      },

      {
        path: '/login',
        element: <Login />
      },

      {
        path: '/quemSomos',
        element: <QuemSomos />
      },
      
      {
        path: '/recuperar',
        element: <Recuperar />
      },
      
      {
        path: '/suporte',
        element: <Suporte />
      },
      
      {
        path: '/usuario',
        element: <Usuario />
      },
    
    ]
  }
])

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RouterProvider router={router}>
      <Outlet />
    </RouterProvider>
  </React.StrictMode>,
)
