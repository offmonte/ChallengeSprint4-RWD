import { Link } from "react-router-dom"
import './style.css'
import './Chroma_Shield.png'

export default function Menu(){
    return(
        <footer>
            <nav class="linksRapidos">
                <p>Links rápidos:</p>
                <ul class="links">
                    <li class="link"><Link to='/suporte'>Suporte</Link></li>
                    <li class="link"><Link to='/quemSomos'>Quem somos</Link></li>
                </ul>
            </nav>

            <div class="shield">
                <ul class="grupo">
                    <li class="integrante">Marcos Henrique Garrido da Silva</li>
                    <li class="integrante">Izabelly de Oliveira Menezes</li>
                    <li class="integrante">João Vito Santiago da Silva</li>
                    <li class="integrante">Gustavo Imparto Chaves</li>
                    <li class="integrante">Lucas Monte Verde</li>
                </ul>
                <img src="src/components/Chroma_Shield.png" height="160px" width="160px"/>
            </div>
        </footer>
    )
}