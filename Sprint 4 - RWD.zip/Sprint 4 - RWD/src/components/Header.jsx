import { Link } from "react-router-dom"
import './style.css'

export default function Menu(){

    return(
        <header>
            <img src="src/components/Chroma_Logo.png" height="200px" width="200" alt="Chroma Cycle Logo" className="logo"/>
            <nav className="navegar">
                <ul className="listaHeader">
                    <li className="itemHeader"><Link to='/home'>Seguros</Link></li>
                    <li className="itemHeader"><Link to='/quemSomos'>Sobre nós</Link></li>
                    <li className="itemHeader"><Link to='/suporte'>Fale conosco</Link></li>
                </ul>
            </nav>
            
        </header>
    )
}